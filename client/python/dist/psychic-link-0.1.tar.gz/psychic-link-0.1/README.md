# Psychic Package

This package provides a simple way to get documents from various SaaS apps such as Notion, Google Drive, Confluence, Zendesk, and more.